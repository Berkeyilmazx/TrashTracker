let map;
let directionsService;
let directionsRenderer;

function initMap() {
    map = new google.maps.Map(document.getElementById('map'), {
        center: { lat: 38.4663, lng: 27.0833 },
        zoom: 13
    });

    directionsService = new google.maps.DirectionsService();
    directionsRenderer = new google.maps.DirectionsRenderer({
        map: map,
        suppressMarkers: false,
        preserveViewport: false,
        polylineOptions: {
            strokeColor: '#1e8449',
            strokeWeight: 5
        }
    });

    // Rota paneli kapatma işlevselliği
    document.querySelector('.route-panel-close').addEventListener('click', () => {
        const routePanel = document.getElementById('route-panel');
        routePanel.classList.remove('active');
        directionsRenderer.setDirections({ routes: [] });
    });

    const bins = [
        { position: { lat: 38.4663, lng: 27.0892 }, title: "Çöp Kutusu #1" },
        { position: { lat: 38.4598, lng: 27.0905 }, title: "Çöp Kutusu #2" },
        { position: { lat: 38.4620, lng: 27.0930 }, title: "Çöp Kutusu #3" }
    ];

    bins.forEach(bin => {
        new google.maps.Marker({
            position: bin.position,
            map: map,
            title: bin.title
        });
    });

    document.getElementById('route-button').addEventListener('click', calculateAndDisplayRoute);
}

function calculateAndDisplayRoute() {
    const routePanel = document.getElementById('route-panel');
    routePanel.innerHTML = '<div class="route-info">Rota hesaplanıyor...</div>';
    routePanel.classList.add('active');

    const start = document.getElementById('start-point').value;
    const end = document.getElementById('end-point').value;

    if (start === 'user-location') {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(position => {
                const userLocation = {
                    lat: position.coords.latitude,
                    lng: position.coords.longitude
                };
                calculateRoute(userLocation, getBinLocation(end));
            }, () => {
                routePanel.innerHTML = '<div class="route-info">Konum alınamadı. Lütfen başka bir başlangıç noktası seçin.</div>';
            });
        } else {
            routePanel.innerHTML = '<div class="route-info">Tarayıcınız konum hizmetini desteklemiyor.</div>';
        }
    } else {
        calculateRoute(getBinLocation(start), getBinLocation(end));
    }
}

function getBinLocation(binId) {
    const binLocations = {
        'bin-1': { lat: 38.4663, lng: 27.0892 },
        'bin-2': { lat: 38.4598, lng: 27.0905 },
        'bin-3': { lat: 38.4620, lng: 27.0930 }
    };
    return binLocations[binId];
}

function calculateRoute(start, end) {
    const now = new Date();
    const routePanel = document.getElementById('route-panel');
    routePanel.innerHTML = `
        <div class="route-info-header">
            <h3>Rota Bilgileri</h3>
            <i class="fa-solid fa-times route-panel-close"></i>
        </div>
        <div class="route-info">
            <span><i class="fa-solid fa-spinner fa-spin"></i> Rota hesaplanıyor...</span>
        </div>
    `;
    routePanel.classList.add('active');

    // Kapatma düğmesi işlevselliğini yeniden ekle
    routePanel.querySelector('.route-panel-close').addEventListener('click', () => {
        routePanel.classList.remove('active');
        directionsRenderer.setDirections({ routes: [] });
    });

    directionsService.route(
        {
            origin: start,
            destination: end,
            travelMode: google.maps.TravelMode.DRIVING,
            drivingOptions: {
                departureTime: now,
                trafficModel: google.maps.TrafficModel.BEST_GUESS
            }
        },
        (response, status) => {
            if (status === 'OK') {
                directionsRenderer.setDirections(response);
                const route = response.routes[0];
                const leg = route.legs[0];
                
                let trafficStatus = "🟢 Normal";
                const normalDuration = leg.duration.value;
                const trafficDuration = leg.duration_in_traffic ? leg.duration_in_traffic.value : normalDuration;
                
                if (trafficDuration > normalDuration * 1.5) {
                    trafficStatus = "🔴 Yoğun";
                } else if (trafficDuration > normalDuration * 1.2) {
                    trafficStatus = "🟡 Orta";
                }

                routePanel.innerHTML = `
                    <div class="route-info-header">
                        <h3>Rota Bilgileri</h3>
                        <i class="fa-solid fa-times route-panel-close"></i>
                    </div>
                    <div class="route-info">
                        <span><i class="fa-solid fa-road"></i> Mesafe: ${leg.distance.text}</span>
                        <span><i class="fa-regular fa-clock"></i> Normal Süre: ${leg.duration.text}</span>
                        <span><i class="fa-solid fa-clock"></i> Trafikli Süre: ${leg.duration_in_traffic ? leg.duration_in_traffic.text : leg.duration.text}</span>
                        <span><i class="fa-solid fa-traffic-light"></i> Trafik Durumu: ${trafficStatus}</span>
                        <span><i class="fa-solid fa-location-dot"></i> Başlangıç: ${leg.start_address}</span>
                        <span><i class="fa-solid fa-flag-checkered"></i> Varış: ${leg.end_address}</span>
                    </div>
                `;

                // Kapatma düğmesi işlevselliğini yeniden ekle
                routePanel.querySelector('.route-panel-close').addEventListener('click', () => {
                    routePanel.classList.remove('active');
                    directionsRenderer.setDirections({ routes: [] });
                });

                map.setOptions({
                    styles: [],
                    trafficLayer: new google.maps.TrafficLayer()
                });
            } else {
                routePanel.innerHTML = `
                    <div class="route-info-header">
                        <h3>Rota Bilgileri</h3>
                        <i class="fa-solid fa-times route-panel-close"></i>
                    </div>
                    <div class="route-info">
                        <span><i class="fa-solid fa-triangle-exclamation"></i> Rota hesaplanamadı. Lütfen tekrar deneyin.</span>
                    </div>
                `;

                // Kapatma düğmesi işlevselliğini yeniden ekle
                routePanel.querySelector('.route-panel-close').addEventListener('click', () => {
                    routePanel.classList.remove('active');
                    directionsRenderer.setDirections({ routes: [] });
                });
            }
        }
    );
}

window.initMap = initMap;