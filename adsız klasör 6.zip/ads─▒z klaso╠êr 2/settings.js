// Dark Mode
const darkModeToggle = document.getElementById('darkModeToggle');
const notificationsToggle = document.getElementById('notificationsToggle');
const languageSelect = document.getElementById('languageSelect');

// Load saved settings
document.addEventListener('DOMContentLoaded', () => {
    // Dark Mode
    const darkMode = localStorage.getItem('darkMode') === 'true';
    darkModeToggle.checked = darkMode;
    document.documentElement.setAttribute('data-theme', darkMode ? 'dark' : 'light');

    // Notifications
    const notifications = localStorage.getItem('notifications') === 'true';
    notificationsToggle.checked = notifications;

    // Language
    const language = localStorage.getItem('language') || 'tr';
    languageSelect.value = language;
});

// Dark Mode Toggle
darkModeToggle.addEventListener('change', () => {
    const darkMode = darkModeToggle.checked;
    document.documentElement.setAttribute('data-theme', darkMode ? 'dark' : 'light');
    localStorage.setItem('darkMode', darkMode);
});

// Notifications Toggle
notificationsToggle.addEventListener('change', () => {
    const notifications = notificationsToggle.checked;
    localStorage.setItem('notifications', notifications);
    
    if (notifications) {
        // Bildirim izni iste
        Notification.requestPermission().then(permission => {
            if (permission === 'granted') {
                new Notification('TrashTracker', {
                    body: 'Bildirimler başarıyla açıldı!',
                    icon: '/path/to/icon.png'
                });
            }
        });
    }
});

// Language Change
languageSelect.addEventListener('change', () => {
    const language = languageSelect.value;
    localStorage.setItem('language', language);
    // Dil değişikliği için sayfayı yenile
    window.location.reload();
}); 