import { initializeApp } from "https://www.gstatic.com/firebasejs/11.4.0/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut } from "https://www.gstatic.com/firebasejs/11.4.0/firebase-auth.js";
import { getDatabase, ref, set, onValue } from "https://www.gstatic.com/firebasejs/11.4.0/firebase-database.js";

const firebaseConfig = {
    apiKey: "AIzaSyA_YgVx8j6hcp9lRzIsZ6FtBurKBxuhDvU",
    authDomain: "trashtracker-9427c.firebaseapp.com",
    projectId: "trashtracker-9427c",
    storageBucket: "trashtracker-9427c.firebasestorage.app",
    messagingSenderId: "858559874459",
    appId: "1:858559874459:web:182e89b7fe64c9c9380d3e",
    measurementId: "G-JNMVEQ233S"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const database = getDatabase(app);

// Modal Logic
const loginModal = document.getElementById('login-modal');
const signupModal = document.getElementById('signup-modal');
const loginButton = document.getElementById('login-button');
const signupButton = document.getElementById('signup-button');
const closeButtons = document.querySelectorAll('.close');
const logoutButton = document.getElementById('logout-button');
const userNameElement = document.getElementById('user-name');
const authButtons = document.querySelector('.auth-buttons');

// Modal events
function openModal(modal) {
    modal.style.display = 'block';
    // Trigger reflow
    modal.offsetHeight;
    modal.classList.add('show');
}

function closeModal(modal) {
    modal.classList.remove('show');
    setTimeout(() => {
        modal.style.display = 'none';
    }, 300); // Match the transition duration in CSS
}

loginButton.onclick = () => openModal(loginModal);
signupButton.onclick = () => openModal(signupModal);

closeButtons.forEach(button => {
    button.onclick = () => {
        const modal = button.closest('.modal');
        closeModal(modal);
    }
});

window.onclick = (event) => {
    if (event.target.classList.contains('modal')) {
        closeModal(event.target);
    }
};

// Login Form
document.getElementById('login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;

    try {
        const userCredential = await signInWithEmailAndPassword(auth, email, password);
        const user = userCredential.user;
        
        // Kullanıcı durumunu güncelle
        await set(ref(database, 'users/' + user.uid + '/status'), 'online');
        
        // Modal'ı kapat
        closeModal(loginModal);
        
        // UI'ı güncelle
        updateUIForLoggedInUser(user);
        
        // Başarı bildirimi
        if (localStorage.getItem('notifications') === 'true') {
            new Notification('TrashTracker', {
                body: 'Başarıyla giriş yaptınız!',
                icon: '/path/to/icon.png'
            });
        }
    } catch (error) {
        alert("Giriş hatası: " + error.message);
    }
});

// Signup Form
document.getElementById('signup-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('signup-email').value;
    const password = document.getElementById('signup-password').value;
    const username = document.getElementById('signup-username').value;
    const phoneNumber = document.getElementById('signup-phone').value;
    const identityNumber = document.getElementById('signup-identity').value;
    const role = document.getElementById('signup-role').value;

    try {
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        const user = userCredential.user;
        
        // Kullanıcı bilgilerini kaydet
        await set(ref(database, 'users/' + user.uid), {
            username: username,
            email: email,
            phone_number: phoneNumber,
            identity_number: identityNumber,
            role: role,
            status: 'online',
            created_at: new Date().toISOString()
        });
        
        // Modal'ı kapat
        closeModal(signupModal);
        
        // UI'ı güncelle
        updateUIForLoggedInUser(user);
        
        // Başarı bildirimi
        if (localStorage.getItem('notifications') === 'true') {
            new Notification('TrashTracker', {
                body: 'Hesabınız başarıyla oluşturuldu!',
                icon: '/path/to/icon.png'
            });
        }
    } catch (error) {
        alert("Kayıt hatası: " + error.message);
    }
});

// Logout
logoutButton.addEventListener('click', async () => {
    try {
        if (auth.currentUser) {
            await set(ref(database, 'users/' + auth.currentUser.uid + '/status'), 'offline');
        }
        await signOut(auth);
        updateUIForLoggedOutUser();
        
        // Çıkış bildirimi
        if (localStorage.getItem('notifications') === 'true') {
            new Notification('TrashTracker', {
                body: 'Başarıyla çıkış yaptınız!',
                icon: '/path/to/icon.png'
            });
        }
    } catch (error) {
        alert("Çıkış hatası: " + error.message);
    }
});

// UI Updates
function updateUIForLoggedInUser(user) {
    logoutButton.style.display = 'flex';
    authButtons.style.display = 'none';
    
    // Kullanıcı verilerini getir
    onValue(ref(database, 'users/' + user.uid), (snapshot) => {
        const userData = snapshot.val();
        if (userData) {
            userNameElement.textContent = userData.username;
            
            // Dark mode tercihini kaydet
            if (userData.preferences?.darkMode !== undefined) {
                document.documentElement.setAttribute('data-theme', userData.preferences.darkMode ? 'dark' : 'light');
                if (darkModeToggle) {
                    darkModeToggle.checked = userData.preferences.darkMode;
                }
            }
        }
    });
}

function updateUIForLoggedOutUser() {
    logoutButton.style.display = 'none';
    authButtons.style.display = 'flex';
    userNameElement.textContent = 'Misafir';
}

// Online Users Tracking
const activeUsersElement = document.getElementById('active-users');
if (activeUsersElement) {
    onValue(ref(database, 'users/'), (snapshot) => {
        const users = snapshot.val();
        let onlineCount = 0;
        for (const userId in users) {
            if (users[userId].status === 'online') {
                onlineCount++;
            }
        }
        activeUsersElement.textContent = onlineCount;
    });
}

// Auth state observer
auth.onAuthStateChanged((user) => {
    if (user) {
        updateUIForLoggedInUser(user);
    } else {
        updateUIForLoggedOutUser();
    }
}); 