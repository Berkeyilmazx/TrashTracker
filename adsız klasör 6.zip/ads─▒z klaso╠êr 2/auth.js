// Kullanıcı verileri
const users = [
    {
        username: 'admin',
        password: 'admin1',
        role: 'admin',
        name: 'Admin User',
        email: 'admin@trashtracker.com'
    },
    {
        username: 'user',
        password: 'user1',
        role: 'user',
        name: 'Normal User',
        email: 'user@trashtracker.com'
    }
];

// Aktif kullanıcı bilgisini saklamak için
let currentUser = null;

// Login işlemi
function login(username, password) {
    const user = users.find(u => u.username === username && u.password === password);
    if (user) {
        currentUser = { ...user };
        // Kullanıcı bilgilerini localStorage'a kaydet
        localStorage.setItem('currentUser', JSON.stringify({
            username: user.username,
            role: user.role,
            name: user.name,
            email: user.email
        }));
        return true;
    }
    return false;
}

// Logout işlemi
function logout() {
    // Kullanıcı bilgilerini temizle
    currentUser = null;
    localStorage.removeItem('currentUser');
    
    // Çıkış yapıldığında login sayfasına yönlendir
    window.location.href = 'login.html';
}

// Kullanıcının login durumunu kontrol et
function checkAuth() {
    const storedUser = localStorage.getItem('currentUser');
    if (storedUser) {
        currentUser = JSON.parse(storedUser);
        return true;
    }
    return false;
}

// Kullanıcının rolünü kontrol et
function checkRole(requiredRole) {
    if (!currentUser) return false;
    return currentUser.role === requiredRole;
}

// Kullanıcı arayüzünü güncelle
function updateUIForLoggedInUser() {
    const userNameSpan = document.getElementById('user-name');
    const logoutButton = document.getElementById('logout-button');
    
    if (userNameSpan && currentUser) {
        // Kullanıcı adını göster (sadece ilk ismi al)
        userNameSpan.textContent = `Merhaba, ${currentUser.name.split(' ')[0]}`;
    }
    
    if (logoutButton) {
        logoutButton.style.display = 'flex';
    }
}

// Sayfa yüklendiğinde login durumunu kontrol et
document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('login-form');
    const loginPanel = document.getElementById('login-panel');
    const loginButton = document.getElementById('login-button');
    const logoutButton = document.getElementById('logout-button');
    const userNameSpan = document.getElementById('user-name');
    const authButtons = document.querySelector('.auth-buttons');
    
    // Login sayfasında değilsek ve giriş yapılmamışsa login sayfasına yönlendir
    if (!window.location.pathname.endsWith('login.html') && !checkAuth()) {
        window.location.href = 'login.html';
        return;
    }

    // Login form submit
    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const username = document.getElementById('login-email')?.value || document.getElementById('username')?.value;
            const password = document.getElementById('login-password')?.value || document.getElementById('password')?.value;

            if (login(username, password)) {
                // Login başarılı
                if (loginPanel) {
                    loginPanel.style.display = 'none';
                    document.querySelector('.auth-overlay').style.display = 'none';
                }
                updateUIForLoggedInUser();
                if (window.location.pathname.endsWith('login.html')) {
                    window.location.href = 'index.html';
                } else {
                    window.location.reload();
                }
            } else {
                alert('Hatalı kullanıcı adı veya şifre!');
            }
        });
    }

    // Login butonu tıklama
    if (loginButton) {
        loginButton.addEventListener('click', () => {
            loginPanel.style.display = 'block';
            document.querySelector('.auth-overlay').style.display = 'block';
        });
    }

    // Login panel kapatma
    document.querySelectorAll('.auth-panel-close').forEach(closeBtn => {
        closeBtn.addEventListener('click', () => {
            document.querySelectorAll('.auth-panel').forEach(panel => panel.style.display = 'none');
            document.querySelector('.auth-overlay').style.display = 'none';
        });
    });

    // Logout butonu tıklama
    if (logoutButton) {
        logoutButton.addEventListener('click', () => {
            // Çıkış yap ve login sayfasına yönlendir
            logout();
        });
    }

    // Sayfa yüklendiğinde UI'ı güncelle
    if (checkAuth()) {
        updateUIForLoggedInUser();
    }
});

/* Firebase Authentication (Daha sonra kullanılmak üzere)
import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js';
import { 
    getAuth, 
    createUserWithEmailAndPassword,
    signInWithEmailAndPassword,
    onAuthStateChanged,
    signOut 
} from 'https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js';

const firebaseConfig = {
    apiKey: "YOUR_API_KEY",
    authDomain: "YOUR_AUTH_DOMAIN",
    projectId: "YOUR_PROJECT_ID",
    storageBucket: "YOUR_STORAGE_BUCKET",
    messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
    appId: "YOUR_APP_ID"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// Kullanıcı durumu değişikliklerini dinle
onAuthStateChanged(auth, (user) => {
    if (user) {
        // Kullanıcı giriş yapmış
        console.log('Giriş yapıldı:', user);
    } else {
        // Kullanıcı çıkış yapmış
        console.log('Çıkış yapıldı');
    }
});

// Yeni kullanıcı kaydı
async function registerUser(email, password) {
    try {
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        return userCredential.user;
    } catch (error) {
        console.error('Kayıt hatası:', error);
        throw error;
    }
}

// Kullanıcı girişi
async function loginUser(email, password) {
    try {
        const userCredential = await signInWithEmailAndPassword(auth, email, password);
        return userCredential.user;
    } catch (error) {
        console.error('Giriş hatası:', error);
        throw error;
    }
}

// Çıkış yap
async function logoutUser() {
    try {
        await signOut(auth);
    } catch (error) {
        console.error('Çıkış hatası:', error);
        throw error;
    }
}
*/ 