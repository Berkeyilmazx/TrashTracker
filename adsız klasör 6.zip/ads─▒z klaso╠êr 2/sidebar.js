class Sidebar {
    constructor() {
        this.sidebar = document.getElementById('sidebar');
        this.init();
    }

    async init() {
        await this.loadSidebar();
        this.setupEventListeners();
        this.setActiveMenuItem();
        this.filterMenuByRole();
    }

    async loadSidebar() {
        try {
            const response = await fetch('sidebar.html');
            const html = await response.text();
            this.sidebar.innerHTML = html;
        } catch (error) {
            console.error('Sidebar yüklenirken hata oluştu:', error);
        }
    }

    setupEventListeners() {
        // Ana menü öğelerine tıklama olayı ekle
        this.sidebar.addEventListener('click', (e) => {
            const menuItem = e.target.closest('.menu-item');
            if (menuItem) {
                const link = menuItem.querySelector('a');
                if (link) {
                    e.preventDefault(); // Varsayılan davranışı engelle
                    const href = link.getAttribute('href');
                    if (href && !href.startsWith('#')) {
                        window.location.href = href;
                    }
                }
            }
        });

        // Alt menü öğelerine tıklama olayı ekle
        this.sidebar.addEventListener('click', (e) => {
            const submenuItem = e.target.closest('.submenu-item');
            if (submenuItem) {
                const link = submenuItem.querySelector('a');
                if (link) {
                    e.preventDefault(); // Varsayılan davranışı engelle
                    const href = link.getAttribute('href');
                    if (href && !href.startsWith('#')) {
                        window.location.href = href;
                    }
                }
            }
        });
        
        // Sidebar içerisindeki Çıkış Yap butonu
        const sidebarLogoutButton = this.sidebar.querySelector('#logout-button');
        if (sidebarLogoutButton) {
            sidebarLogoutButton.addEventListener('click', () => {
                // Global logout fonksiyonunu çağır (main script'te tanımlı olmalı)
                if (typeof logout === 'function') {
                    logout();
                } else {
                    console.error('Global logout fonksiyonu bulunamadı.');
                }
            });
        }
    }

    setActiveMenuItem() {
        // Aktif menü öğesini belirle
        const currentPath = window.location.pathname;
        const menuItems = this.sidebar.querySelectorAll('.menu-item a');
        
        menuItems.forEach(item => {
            const href = item.getAttribute('href');
            if (href && currentPath.endsWith(href)) {
                item.parentElement.classList.add('active');
                
                // Eğer alt menüdeyse, üst menüyü de aktif yap
                const submenu = item.closest('.submenu');
                if (submenu) {
                    const parentMenuItem = submenu.previousElementSibling;
                    if (parentMenuItem && parentMenuItem.classList.contains('menu-item')) {
                        parentMenuItem.classList.add('active');
                    }
                }
            }
        });
    }

    filterMenuByRole() {
        // Kullanıcı rolünü kontrol et
        const currentUser = JSON.parse(localStorage.getItem('currentUser'));
        
        // Eğer kullanıcı admin değilse, sadece rota hesaplama menüsünü göster
        if (currentUser && currentUser.role !== 'admin') {
            const menuItems = this.sidebar.querySelectorAll('.menu-item');
            
            // Tüm menü öğelerini gizle
            menuItems.forEach(item => {
                item.style.display = 'none';
            });
            
            // Sadece rota hesaplama menüsünü göster
            const routeMenuItem = this.sidebar.querySelector('.menu-item a[href="route_generate.html"]');
            if (routeMenuItem) {
                routeMenuItem.parentElement.style.display = 'flex';
            }
            
            // Menü başlıklarını kontrol et ve boş başlıkları gizle
            const menuTitles = this.sidebar.querySelectorAll('.menu-title');
            menuTitles.forEach(title => {
                const nextElement = title.nextElementSibling;
                if (nextElement && nextElement.classList.contains('menu-items')) {
                    const visibleItems = nextElement.querySelectorAll('.menu-item[style="display: flex"]');
                    if (visibleItems.length === 0) {
                        title.style.display = 'none';
                        nextElement.style.display = 'none';
                    }
                }
            });
        }
    }
}

// Sidebar'ı başlat
document.addEventListener('DOMContentLoaded', () => {
    new Sidebar();
});